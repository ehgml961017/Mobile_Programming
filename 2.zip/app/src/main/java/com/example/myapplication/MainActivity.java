package com.example.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView res;
    EditText input;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        res = (TextView) findViewById(R.id.textView);
        input = (EditText) findViewById(R.id.editText);
    }
//    public void onButtonClicked1(View v){
//        Toast.makeText(this, "button1 click", Toast.LENGTH_SHORT).show();
//    }
//    public void onButtonClicked2(View v){
//        Toast.makeText(this, "button2 click", Toast.LENGTH_SHORT).show();
//    }
//
//    public void onButtonClicked3(View v){
//        Toast.makeText(this, "button3 click", Toast.LENGTH_SHORT).show();
//    }

    int list[];
    int result;
    int aver;

    public void getMinimum(View v)
    {
        makeList();
        result = list[0];
        for( int i : list){
            if(result>i) result = i;
        }

        res.setText("The Minimum :"  + Integer.toString(result));
    }


//    public void getMaximum(View v)
//    {
//        result = 65;
//        res.setText("The Maximum : " + Integer.toString(result));
//        Toast.makeText(this, "The Results : "+result, Toast.LENGTH_SHORT).show();
//    }

    public void getAverage(View v)
    {
        makeList();
        aver=0;
        for(int i : list)
        {
            aver+=i;
        }
        aver /= list.length;
        res.setText("The Average : " + Integer.toString(aver));
    }

    public void makeList()
    {
        String tmp = input.getText().toString();
        String[] arr = tmp.split(" ");
        list = new int[arr.length];
        for(int i=0;i<arr.length;i++){
            list[i] = Integer.parseInt(arr[i]);
        }
    }
}